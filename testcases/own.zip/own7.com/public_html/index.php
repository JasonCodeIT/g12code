<html>

<title>
Own7.com
</title>


<body>

<form action="own7secondpage.php" id="own7form" method="post">
	User: <input type="text" name="user"></input>
<br>	
	Pass: <input type="password" name="password"></input>
<br>
	<input type="submit" value="Go!">
</form>

</body>



</html>
