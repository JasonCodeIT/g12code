<?php

$expose = $_POST['path'];

include($expose);

?>
