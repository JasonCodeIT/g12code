<?php

$page = $_GET["language"];
$comm = $_GET["comment"];

echo "You said: " . $comm;

echo "<br>";

echo "Language Selected: ";
echo "<br>";
include($_GET['language']);

?>
