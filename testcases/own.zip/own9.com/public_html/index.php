<h1>File Submission</h1>
<h2>Doesn't really submit files... </h2>
<br>
<form action="own9submit.php" method="POST" enctype="multipart/form-data">
<input type="hidden" name="MAX_FILE_SIZE" value="10000000">
<input type="hidden" name="FILE_PATH" value=".">
<br><input type="file" name="file">
<br><input type="submit" value="submit">
</form>
