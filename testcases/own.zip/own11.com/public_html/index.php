<!DOCTYPE html>
<html>
<head>
	<title>Test Case 11</title>
</head>
<body>

	<h1>Login using admin account to view files</h1>
	<p>Hint: admin is a common user name and password</p>
	<form action = "./login.php" method = "post">
		Enter your username here:<br>
		<input type="text" name="username">
		<br>
		Enter password here:<br>
		<input type="password" name="password">
		<br>
		<input type = "submit" value = "submit">
	</form>	
</body>
</html>
